# RUNBOOK — lectures Cassandra en échec sur un salon

## Symptôme

La lecture de l’historique d’un salon échoue avec une `ReadFailure` ou une erreur signalant trop de tombstones. Le problème peut concerner une partition ancienne avec de nombreuses suppressions, même si peu de messages restent visibles. Le résultat exact et la latence doivent être consignés avec le salon, la partition, l’heure et le nombre de tombstones indiqué par l’erreur ou les journaux.

## Diagnostic

1. Vérifier que le service répond et identifier le salon et la fenêtre `(salon_id, bucket)` concernés.
2. Relever l’erreur applicative complète, puis examiner les journaux :
   ```bash
   docker compose --profile colonne logs --since=15m cassandra
   ```
3. Chercher le seuil dépassé et le nombre de tombstones parcourues. Distinguer une partition très supprimée d’une panne générale ou d’une requête sans clé de partition.
4. Ne pas augmenter `tombstone_failure_threshold` pour masquer l’incident : cela peut transformer un échec rapide en longue pause qui affecte les autres requêtes.
5. Sur un environnement de TP, reproduire le cas dans `bench/` avec `python tombstones.py`. Conserver le message d’erreur et le journal comme preuve.

## Action immédiate

- Si une version saine est reconstruisible depuis la source de vérité, préférer une reconstruction contrôlée dans une nouvelle partition, puis basculer les lectures après vérification.
- Pour la démonstration du TP, `python tombstones.py --reparer` montre une stratégie différente : réinitialisation/rechargement, puis suppression de la partition entière plutôt que 119 999 suppressions individuelles. Comparer les lectures avant et après et noter la sortie exacte.
- La purge accélérée de l’annexe B est réservée au TP mono-nœud :
  ```sql
  ALTER TABLE discord.messages_par_salon WITH gc_grace_seconds = 0;
  ```
  ```bash
  docker compose --profile colonne exec cassandra nodetool flush discord messages_par_salon
  docker compose --profile colonne exec cassandra nodetool compact discord messages_par_salon
  ```
  ```sql
  ALTER TABLE discord.messages_par_salon WITH gc_grace_seconds = 864000;
  ```
  Répéter la lecture et conserver sa sortie. Vérifier ensuite que `gc_grace_seconds` est revenu à sa valeur initiale.

**Danger :** ne pas réduire `gc_grace_seconds` à zéro en production. Sur plusieurs répliques, une réplique indisponible pendant la suppression pourrait conserver l’ancienne ligne ; une compaction qui élimine les tombstones avant réparation peut faire réapparaître cette ligne lors d’une réparation ultérieure. En production, coordonner réparation, réplication et compaction avec l’astreinte Cassandra.

## Prévention

- Ne jamais écrire de `NULL` pour représenter une valeur absente ; omettre les colonnes non renseignées (`UNSET_VALUE`).
- Éviter les suppressions massives ligne par ligne sur une partition potentiellement énorme. Concevoir une rétention par partition/fenêtre et une stratégie de reconstruction ou de suppression de plage.
- Suivre le nombre de tombstones lues, les avertissements/échecs, la durée des lectures, les pauses de compactage et la taille des partitions.
- Alerter sur la croissance anormale du nombre de tombstones par lecture et sur l’approche du seuil Cassandra, avant les erreurs utilisateurs.
- Garder un inventaire des fenêtres non vides pour éviter de scanner inutilement les fenêtres vides, tout en maintenant cet index secondaire cohérent.

## Preuves du TP

La reproduction du 14 novembre 2026 a lu 50 messages en 10 ms, puis échoué après 119 999 suppressions en 255 ms. Une répétition a lu 50 en 4 ms et échoué en 144 ms. Le journal Cassandra signale `Read 0 live rows and 100001 tombstone cells`, puis `Scanned over 100001 tombstones` et `query aborted` pour la partition `(-1, 0)`. La sortie applicative est tronquée à 160 caractères par `tombstones.py`. Le journal reconstruit la requête en `SELECT * ... ALLOW FILTERING`, alors que le script envoie `SELECT message_id ... LIMIT 50` : Cassandra précise que sa représentation CQL de diagnostic n’est pas toujours identique à la requête d’origine ([code Cassandra 4.1](https://github.com/apache/cassandra/blob/cassandra-4.1/src/java/org/apache/cassandra/db/AbstractReadQuery.java#L86-L109)). Le nombre de tombstones et la partition concordent.

La purge locale de TP (`gc_grace_seconds = 0`, `nodetool flush`, `nodetool compact`, restauration à 864000) a laissé le message vivant `message_id = 1`, vérifié par une lecture ciblée (1 ligne). Le scénario `python tombstones.py --reparer` a lu 50 messages en 4 ms avant de supprimer la partition entière, puis 0 message en 8 ms. Ces opérations ont été réalisées sur le Cassandra mono-nœud du TP ; ne pas transposer la purge accélérée en production.
