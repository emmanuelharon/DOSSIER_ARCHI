"""Alimente MongoDB, Cassandra, Redis et Neo4j à partir de PostgreSQL (source de vérité du TP).

Usage : python load_nosql.py [--sans-cassandra]
"""
import argparse
import json
import random

from cassandra import ConsistencyLevel
from cassandra.concurrent import execute_concurrent_with_args
from cassandra.query import UNSET_VALUE

from common import bucket_de, cassandra_session, mongo_db, neo_driver, pg_conn, redis_conn

ap = argparse.ArgumentParser()
ap.add_argument("--sans-cassandra", action="store_true")
args = ap.parse_args()
pg = pg_conn()


def lots(curseur, taille):
    while True:
        rows = curseur.fetchmany(taille)
        if not rows:
            return
        yield rows


# ---------- MongoDB : la configuration « 2015 » — une collection, un index composé ----------
# Implémentation : un document par message, pièce jointe omise si absente.
# Index B1 : salon + identifiant décroissant. Index B4 : serveur + date d'envoi.
db = mongo_db()
messages = db.messages
messages.drop()

# B1 : les 50 derniers messages d'un salon, dans l'ordre décroissant.
messages.create_index([("salon_id", 1), ("_id", -1)])
# B4 : activité quotidienne d'un serveur sur une période donnée.
messages.create_index([("serveur_id", 1), ("envoye_le", 1)])

with pg.cursor() as curseur:
    curseur.execute("""
        SELECT m.id, m.salon_id, s.serveur_id, m.auteur_id,
               m.contenu, m.envoye_le, m.pieces_jointes
        FROM app.message m
        JOIN app.salon s ON s.id = m.salon_id
        ORDER BY m.id
    """)
    for lignes in lots(curseur, 5_000):
        documents = []
        for identifiant, salon_id, serveur_id, auteur_id, contenu, envoye_le, pieces_jointes in lignes:
            document = {
                "_id": identifiant,
                "salon_id": salon_id,
                "serveur_id": serveur_id,
                "auteur_id": auteur_id,
                "contenu": contenu,
                "envoye_le": envoye_le,
            }
            if pieces_jointes is not None:
                document["pieces_jointes"] = pieces_jointes
            documents.append(document)
        messages.insert_many(documents, ordered=False)

print(f"mongo     : {messages.count_documents({})} messages")


# ---------- Cassandra : une table = une requête ----------
# Implémentation : partition (salon_id, bucket de 10 jours), chargement concurrent depuis PostgreSQL.
# Les champs absents sont transmis avec UNSET_VALUE pour éviter d'écrire des NULL/tombstones.
if not args.sans_cassandra:
    cs = cassandra_session()
    cs.set_keyspace("discord")
    cs.execute("TRUNCATE messages_par_salon")
    insertion = cs.prepare("""
        INSERT INTO messages_par_salon
            (salon_id, bucket, message_id, auteur_id, contenu, envoye_le,
             modifie_le, pieces_jointes)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    """)

    total_cassandra = 0
    with pg.cursor() as curseur:
        curseur.execute("""
            SELECT id, salon_id, auteur_id, contenu, envoye_le,
                   modifie_le, pieces_jointes
            FROM app.message
            ORDER BY id
        """)
        for lignes in lots(curseur, 1_000):
            valeurs = []
            for message_id, salon_id, auteur_id, contenu, envoye_le, modifie_le, pieces_jointes in lignes:
                valeurs.append((
                    salon_id,
                    bucket_de(message_id),
                    message_id,
                    auteur_id,
                    contenu,
                    envoye_le,
                    modifie_le if modifie_le is not None else UNSET_VALUE,
                    json.dumps(pieces_jointes, ensure_ascii=False)
                    if pieces_jointes is not None else UNSET_VALUE,
                ))
            resultats = execute_concurrent_with_args(
                cs, insertion, valeurs, concurrency=100, raise_on_first_error=True
            )
            if not all(succes for succes, _ in resultats):
                raise RuntimeError("Une écriture Cassandra a échoué")
            total_cassandra += len(valeurs)

    print(f"cassandra : {total_cassandra} écritures confirmées")

# ---------- Redis : présence (TTL 5 min) + ensembles de membres ----------
r = redis_conn()
r.flushdb()
rnd = random.Random(7)
users = [u for (u,) in pg.execute("SELECT id FROM app.utilisateur").fetchall()]
en_ligne = set(rnd.sample(users, int(len(users) * 0.3)))
pipe = r.pipeline()
for u in en_ligne:
    pipe.set(f"presence:{u}", "en_ligne", ex=300)
for serv, mem in pg.execute("SELECT serveur_id, array_agg(utilisateur_id) FROM app.membre GROUP BY 1").fetchall():
    pipe.sadd(f"membres:{serv}", *mem)
pipe.execute()
pg.execute("TRUNCATE app.presence")
with pg.cursor() as c:
    c.executemany("INSERT INTO app.presence VALUES (%s, now())", [(u,) for u in sorted(en_ligne)])
print(f"redis     : {r.dbsize()} clés ({len(en_ligne)} présences)")

# ---------- Neo4j : amitiés et appartenances ----------
drv = neo_driver()
with drv.session() as s:
    s.run("MATCH (n) DETACH DELETE n")
    s.run("CREATE CONSTRAINT utilisateur_id IF NOT EXISTS FOR (u:Utilisateur) REQUIRE u.id IS UNIQUE")
    s.run("CREATE CONSTRAINT serveur_id IF NOT EXISTS FOR (s:Serveur) REQUIRE s.id IS UNIQUE")
    s.run("UNWIND $ids AS i MERGE (:Utilisateur {id: i})", ids=users)
    s.run("UNWIND $ids AS i MERGE (:Serveur {id: i})", ids=[x for (x,) in pg.execute("SELECT id FROM app.serveur").fetchall()])
    am = pg.execute("SELECT utilisateur_a, utilisateur_b FROM app.amitie").fetchall()
    for i in range(0, len(am), 5000):
        s.run("UNWIND $rows AS r MATCH (a:Utilisateur {id: r[0]}), (b:Utilisateur {id: r[1]}) MERGE (a)-[:AMI_DE]->(b)", rows=[list(x) for x in am[i:i + 5000]])
    me = pg.execute("SELECT utilisateur_id, serveur_id FROM app.membre").fetchall()
    for i in range(0, len(me), 5000):
        s.run("UNWIND $rows AS r MATCH (u:Utilisateur {id: r[0]}), (v:Serveur {id: r[1]}) MERGE (u)-[:MEMBRE_DE]->(v)", rows=[list(x) for x in me[i:i + 5000]])
    for t in ("AMI_DE", "MEMBRE_DE"):
        print(f"neo4j     : {s.run(f'MATCH ()-[r:{t}]->() RETURN count(r) AS n').single()['n']} relations {t}")
