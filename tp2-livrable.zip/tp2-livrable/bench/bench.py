"""Benchmark : chaque cas d'usage, chaque moteur qui y prétend, mêmes entrées.

Usage : python bench.py [--n 300]
Affiche un tableau Markdown à coller dans MESURES.md. Les résultats des moteurs sont comparés avant chronométrage (asserts). Le correctif Cassandra par fenêtres non vides est optionnel.
"""
import argparse
import random
import statistics
import time
from datetime import datetime, timezone

from common import bucket_de, cassandra_session, mongo_db, neo_driver, pg_conn, redis_conn

pg, mdb, rds, neo = pg_conn(), mongo_db(), redis_conn(), neo_driver()
cs = cassandra_session("discord")
SELECT_CS = cs.prepare("SELECT message_id FROM messages_par_salon WHERE salon_id = ? AND bucket = ? LIMIT ?")
NEO = neo.session()

SALON_CHAUD, SALON_MOYEN, SALON_CLAIRSEME = 775, 424, 340   # 12 952 / 90 / 2 messages
DERNIER_BUCKET = bucket_de(pg.execute("SELECT max(id) FROM app.message").fetchone()[0])
CREATION = {s: bucket_de(int(c.timestamp() * 1000 - 1420070400000) << 22)
            for s, c in pg.execute("SELECT id, cree_le FROM app.salon").fetchall()}
NB_UTILISATEURS = pg.execute("SELECT max(id) FROM app.utilisateur").fetchone()[0]
SERVEUR_TEST = 118
# Octobre 2026 complet : [1er oct., 1er nov.[ , soit 31 jours (même période que R3 et la Mesure 4).
DEBUT, FIN = datetime(2026, 10, 1, tzinfo=timezone.utc), datetime(2026, 11, 1, tzinfo=timezone.utc)


# ---------- B1. Les 50 derniers messages d'un salon ----------
def b1_pg(salon):
    return [x[0] for x in pg.execute("SELECT id FROM app.message WHERE salon_id = %s ORDER BY id DESC LIMIT 50", (salon,)).fetchall()]


def b1_mongo(salon):
    # Index (salon_id, _id desc) : parcours de l'index puis lecture de 50 documents.
    return [d["_id"] for d in mdb.messages.find({"salon_id": salon}, {"_id": 1}).sort("_id", -1).limit(50)]


def b1_cassandra(salon):
    # Une partition = (salon, fenêtre de 10 jours). On part de la fenêtre la plus récente de la plateforme
    # et on remonte, une partition après l'autre, jusqu'à avoir 50 messages ou atteindre la création du salon.
    ids = []
    bucket = DERNIER_BUCKET
    while bucket >= CREATION[salon] and len(ids) < 50:
        ids.extend(r.message_id for r in cs.execute(SELECT_CS, (salon, bucket, 50 - len(ids))))
        bucket -= 1
    return ids


def b1_cassandra_fenetres(salon):
    raise NotImplementedError("À FAIRE (mission 3, optionnel) — votre correctif aux lectures de fenêtres vides")


# ---------- B2. Présence : battement de cœur (écriture) et « combien sont en ligne dans ce serveur ? » (lecture) ----------
def b2w_pg(uid):
    pg.execute("INSERT INTO app.presence VALUES (%s, now()) ON CONFLICT (utilisateur_id) DO UPDATE SET vu_le = now()", (uid,))


def b2w_redis(uid):
    rds.set(f"presence:{uid}", "en_ligne", ex=300)   # expire tout seul après 5 minutes

def b2r_pg(serveur):
    return pg.execute("""SELECT count(*) FROM app.membre m JOIN app.presence p ON p.utilisateur_id = m.utilisateur_id
                         WHERE m.serveur_id = %s AND p.vu_le > now() - interval '5 minutes'""", (serveur,)).fetchone()[0]


def b2r_redis(serveur):
    membres = rds.smembers(f"membres:{serveur}")
    if not membres:
        return 0
    return sum(1 for v in rds.mget([f"presence:{u}" for u in membres]) if v is not None)


# ---------- B3. Suggestions : serveurs où au moins 2 de mes amis sont membres et pas moi ----------
def b3_pg(uid):
    return pg.execute("""
        SELECT m.serveur_id, count(*) AS n
        FROM (SELECT utilisateur_b AS ami FROM app.amitie WHERE utilisateur_a = %(u)s
              UNION ALL SELECT utilisateur_a FROM app.amitie WHERE utilisateur_b = %(u)s) f
        JOIN app.membre m ON m.utilisateur_id = f.ami
        WHERE m.serveur_id NOT IN (SELECT serveur_id FROM app.membre WHERE utilisateur_id = %(u)s)
        GROUP BY m.serveur_id HAVING count(*) >= 2 ORDER BY n DESC, m.serveur_id LIMIT 5""", {"u": uid}).fetchall()


def b3_neo(uid):
    res = NEO.run("""
        MATCH (u:Utilisateur {id: $u})-[:AMI_DE]-(f:Utilisateur)-[:MEMBRE_DE]->(s:Serveur)
        WHERE NOT (u)-[:MEMBRE_DE]->(s)
        WITH s, count(f) AS n WHERE n >= 2
        RETURN s.id AS serveur_id, n ORDER BY n DESC, s.id LIMIT 5""", u=uid)
    return [(r["serveur_id"], r["n"]) for r in res]


# ---------- B3 bis. Amis d'amis : personnes que je ne connais pas, classées par nombre d'amis communs ----------
def b3bis_pg(uid):
    return pg.execute("""
        WITH amis AS (
            SELECT utilisateur_b AS ami FROM app.amitie WHERE utilisateur_a = %(u)s
            UNION ALL
            SELECT utilisateur_a FROM app.amitie WHERE utilisateur_b = %(u)s
        ), amis_d_amis AS (
            SELECT a.utilisateur_b AS cand, f.ami FROM amis f JOIN app.amitie a ON a.utilisateur_a = f.ami
            UNION ALL
            SELECT a.utilisateur_a, f.ami FROM amis f JOIN app.amitie a ON a.utilisateur_b = f.ami
        )
        SELECT cand, count(*) AS n
        FROM amis_d_amis
        WHERE cand <> %(u)s AND cand NOT IN (SELECT ami FROM amis)
        GROUP BY cand ORDER BY n DESC, cand LIMIT 10""", {"u": uid}).fetchall()


def b3bis_neo(uid):
    res = NEO.run("""
        MATCH (u:Utilisateur {id: $u})-[:AMI_DE]-(f:Utilisateur)-[:AMI_DE]-(c:Utilisateur)
        WHERE c <> u AND NOT (u)-[:AMI_DE]-(c)
        RETURN c.id AS cand, count(DISTINCT f) AS n ORDER BY n DESC, c.id LIMIT 10""", u=uid)
    return [(r["cand"], r["n"]) for r in res]


# ---------- B4. Activité d'un serveur : messages et auteurs distincts par jour, octobre 2026 ----------
def b4_pg_normalise(serveur):
    return pg.execute("""
        SELECT date_trunc('day', m.envoye_le)::date AS jour, count(*) AS nb_messages, count(DISTINCT m.auteur_id) AS nb_auteurs
        FROM app.message m JOIN app.salon s ON s.id = m.salon_id
        WHERE s.serveur_id = %s AND m.envoye_le >= %s AND m.envoye_le < %s
        GROUP BY 1 ORDER BY 1""", (serveur, DEBUT, FIN)).fetchall()


def b4_pg_vue(serveur):
    return pg.execute("""
        SELECT jour, nb_messages, nb_auteurs FROM app.activite_serveur_jour
        WHERE serveur_id = %s AND jour >= %s AND jour < %s ORDER BY jour""", (serveur, DEBUT.date(), FIN.date())).fetchall()


def b4_mongo(serveur):
    res = mdb.messages.aggregate([
        {"$match": {"serveur_id": serveur, "envoye_le": {"$gte": DEBUT, "$lt": FIN}}},
        {"$group": {"_id": {"$dateTrunc": {"date": "$envoye_le", "unit": "day"}},
                    "nb_messages": {"$sum": 1}, "auteurs": {"$addToSet": "$auteur_id"}}},
        {"$project": {"nb_messages": 1, "nb_auteurs": {"$size": "$auteurs"}}},
        {"$sort": {"_id": 1}},
    ])
    return [(d["_id"].date(), d["nb_messages"], d["nb_auteurs"]) for d in res]


def chrono(f, entrees, echauffement=10):
    for e in entrees[:echauffement]:
        f(*e)
    t = []
    for e in entrees:
        t0 = time.perf_counter()
        f(*e)
        t.append((time.perf_counter() - t0) * 1000)
    t.sort()
    return statistics.median(t), t[int(len(t) * 0.95) - 1]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=300)
    n = ap.parse_args().n
    rnd = random.Random(1)

    # ---- Contrôles de cohérence AVANT tout chronométrage : un benchmark dont les moteurs ne répondent pas pareil ne mesure rien ----
    r2 = random.Random(2)
    echantillon = [r2.randint(1, NB_UTILISATEURS) for _ in range(20)]
    for salon in (SALON_CHAUD, SALON_MOYEN, SALON_CLAIRSEME):
        assert b1_pg(salon) == b1_mongo(salon) == b1_cassandra(salon), f"B1 : les moteurs divergent pour le salon {salon}"
    assert b2r_pg(SERVEUR_TEST) > 0, "B2b : plus aucune présence (TTL de 5 min dépassé) : relancez load_nosql.py puis bench.py aussitôt"
    assert b2r_pg(SERVEUR_TEST) == b2r_redis(SERVEUR_TEST), "B2b : PostgreSQL et Redis divergent"
    assert any(b3_pg(u) for u in echantillon), "B3 : échantillon sans aucune suggestion, contrôle sans valeur"
    for u in echantillon:
        assert b3_pg(u) == b3_neo(u), f"B3 : divergence pour l'utilisateur {u}"
        assert b3bis_pg(u) == b3bis_neo(u), f"B3 bis : divergence pour l'utilisateur {u}"
    assert b4_pg_normalise(SERVEUR_TEST) == b4_pg_vue(SERVEUR_TEST) == b4_mongo(SERVEUR_TEST), "B4 : divergence entre moteurs"
    print("Contrôles de cohérence : OK\n")

    lignes = []

    def mesure(cas, moteur, f, entrees):
        try:
            p50, p95 = chrono(f, entrees)
            lignes.append(f"| {cas} | {moteur} | {p50:.2f} | {p95:.2f} |")
        except NotImplementedError:
            lignes.append(f"| {cas} | {moteur} | à faire | à faire |")

    for nom, salon in (("chaud", SALON_CHAUD), ("moyen", SALON_MOYEN), ("clairsemé", SALON_CLAIRSEME)):
        e = [(salon,)] * n
        cas = f"B1 50 derniers messages, salon {nom}"
        mesure(cas, "PostgreSQL", b1_pg, e)
        mesure(cas, "MongoDB", b1_mongo, e)
        mesure(cas, "Cassandra", b1_cassandra, e)
        mesure(cas, "Cassandra + votre correctif (optionnel)", b1_cassandra_fenetres, e)
    e = [(rnd.randint(1, NB_UTILISATEURS),) for _ in range(n)]
    mesure("B2a présence : écriture", "PostgreSQL", b2w_pg, e)
    mesure("B2a présence : écriture", "Redis", b2w_redis, e)
    e = [(SERVEUR_TEST,)] * n
    mesure("B2b présence : en ligne dans un serveur (478 membres)", "PostgreSQL", b2r_pg, e)
    mesure("B2b présence : en ligne dans un serveur (478 membres)", "Redis", b2r_redis, e)
    e = [(rnd.randint(1, NB_UTILISATEURS),) for _ in range(n)]
    mesure("B3 serveurs suggérés (amis)", "PostgreSQL", b3_pg, e)
    mesure("B3 serveurs suggérés (amis)", "Neo4j", b3_neo, e)
    e = [(rnd.randint(1, NB_UTILISATEURS),) for _ in range(30)]
    mesure("B3 bis amis d'amis (n=30)", "PostgreSQL", b3bis_pg, e)
    mesure("B3 bis amis d'amis (n=30)", "Neo4j", b3bis_neo, e)
    e = [(SERVEUR_TEST,)] * n
    mesure("B4 activité d'un serveur (31 j)", "PostgreSQL normalisé", b4_pg_normalise, e)
    mesure("B4 activité d'un serveur (31 j)", "PostgreSQL vue matérialisée", b4_pg_vue, e)
    mesure("B4 activité d'un serveur (31 j)", "MongoDB (aggregate)", b4_mongo, e)

    print(f"| Cas | Moteur | p50 (ms) | p95 (ms) |   (n = {n})\n|---|---|---:|---:|")
    print("\n".join(lignes))


if __name__ == "__main__":
    main()
