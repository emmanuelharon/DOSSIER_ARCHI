CREATE SCHEMA IF NOT EXISTS app;

CREATE TABLE app.utilisateur (
    id       bigint PRIMARY KEY,
    pseudo   text NOT NULL UNIQUE,
    email    text NOT NULL UNIQUE,
    cree_le  timestamptz NOT NULL
);

CREATE TABLE app.serveur (
    id              bigint PRIMARY KEY,
    nom             text NOT NULL,
    proprietaire_id bigint NOT NULL REFERENCES app.utilisateur(id),
    nb_membres      integer NOT NULL DEFAULT 0 CHECK (nb_membres >= 0),
    cree_le         timestamptz NOT NULL
);

CREATE TABLE app.salon (
    id         bigint PRIMARY KEY,
    serveur_id bigint NOT NULL REFERENCES app.serveur(id) ON DELETE CASCADE,
    nom        text NOT NULL,
    type       text NOT NULL CHECK (type IN ('texte', 'vocal')),
    cree_le    timestamptz NOT NULL,
    UNIQUE (serveur_id, nom)
);

CREATE TABLE app.membre (
    utilisateur_id bigint NOT NULL REFERENCES app.utilisateur(id) ON DELETE CASCADE,
    serveur_id     bigint NOT NULL REFERENCES app.serveur(id) ON DELETE CASCADE,
    role           text NOT NULL CHECK (role IN ('proprietaire', 'moderateur', 'membre')),
    rejoint_le     timestamptz NOT NULL,
    PRIMARY KEY (utilisateur_id, serveur_id)
);

CREATE TABLE app.message (
    id             bigint PRIMARY KEY,
    salon_id       bigint NOT NULL REFERENCES app.salon(id) ON DELETE CASCADE,
    auteur_id      bigint NOT NULL REFERENCES app.utilisateur(id),
    contenu        text NOT NULL,
    envoye_le      timestamptz NOT NULL,
    modifie_le     timestamptz,
    pieces_jointes jsonb
);

CREATE TABLE app.amitie (
    utilisateur_a bigint NOT NULL REFERENCES app.utilisateur(id) ON DELETE CASCADE,
    utilisateur_b bigint NOT NULL REFERENCES app.utilisateur(id) ON DELETE CASCADE,
    depuis        timestamptz NOT NULL,
    PRIMARY KEY (utilisateur_a, utilisateur_b),
    CHECK (utilisateur_a < utilisateur_b)
);

CREATE TABLE app.presence (
    utilisateur_id bigint PRIMARY KEY REFERENCES app.utilisateur(id) ON DELETE CASCADE,
    vu_le           timestamptz NOT NULL
);

-- Accélère la vérification et les recherches des serveurs d'un propriétaire.
CREATE INDEX idx_serveur_proprietaire ON app.serveur(proprietaire_id);

-- Accélère la recherche des salons d'un serveur, utilisée par R3.
CREATE INDEX idx_salon_serveur ON app.salon(serveur_id);

-- Accélère le comptage et la recherche des membres d'un serveur.
CREATE INDEX idx_membre_serveur ON app.membre(serveur_id);

-- Accélère R1 : les derniers messages d'un salon dans l'ordre décroissant.
CREATE INDEX idx_message_salon_id ON app.message(salon_id, id DESC);

-- Accélère la recherche des messages écrits par un utilisateur.
CREATE INDEX idx_message_auteur ON app.message(auteur_id);

-- Accélère la recherche des amitiés où l'utilisateur est dans la seconde colonne.
CREATE INDEX idx_amitie_b ON app.amitie(utilisateur_b);

