BEGIN;

INSERT INTO app.utilisateur (id, pseudo, email, cree_le)
SELECT id::bigint, pseudo, email, cree_le::timestamptz
FROM staging.utilisateurs;

INSERT INTO app.serveur (id, nom, proprietaire_id, cree_le)
SELECT id::bigint, nom, proprietaire_id::bigint, cree_le::timestamptz
FROM staging.serveurs;

INSERT INTO app.salon (id, serveur_id, nom, type, cree_le)
SELECT id::bigint, serveur_id::bigint, nom, type, cree_le::timestamptz
FROM staging.salons;

INSERT INTO app.membre (utilisateur_id, serveur_id, role, rejoint_le)
SELECT utilisateur_id::bigint, serveur_id::bigint, role, rejoint_le::timestamptz
FROM staging.membres;

INSERT INTO app.message
    (id, salon_id, auteur_id, contenu, envoye_le, modifie_le, pieces_jointes)
SELECT
    id::bigint,
    salon_id::bigint,
    auteur_id::bigint,
    contenu,
    envoye_le::timestamptz,
    NULLIF(modifie_le, '')::timestamptz,
    NULLIF(pieces_jointes, '')::jsonb
FROM staging.messages;

INSERT INTO app.amitie (utilisateur_a, utilisateur_b, depuis)
SELECT utilisateur_a::bigint, utilisateur_b::bigint, depuis::timestamptz
FROM staging.amities;

UPDATE app.serveur s
SET nb_membres = (
    SELECT count(*)
    FROM app.membre m
    WHERE m.serveur_id = s.id
);

COMMIT;
