-- R1 : les 50 derniers messages du salon chaud, avec le pseudo de l'auteur.
-- Pour une page suivante, remplace la grande valeur par le plus petit ID
-- de la page précédente.

\timing on
SELECT m.id, m.envoye_le, m.contenu, u.pseudo
FROM app.message m
JOIN app.utilisateur u ON u.id = m.auteur_id
WHERE m.salon_id = 775
  AND m.id < 9223372036854775807
ORDER BY m.id DESC
LIMIT 50;

-- R1 : salon moyen.
SELECT m.id, m.envoye_le, m.contenu, u.pseudo
FROM app.message m
JOIN app.utilisateur u ON u.id = m.auteur_id
WHERE m.salon_id = 424
  AND m.id < 9223372036854775807
ORDER BY m.id DESC
LIMIT 50;

-- R1 : salon clairsemé.
SELECT m.id, m.envoye_le, m.contenu, u.pseudo
FROM app.message m
JOIN app.utilisateur u ON u.id = m.auteur_id
WHERE m.salon_id = 340
  AND m.id < 9223372036854775807
ORDER BY m.id DESC
LIMIT 50;

-- R2 : l'utilisateur 1 peut-il écrire dans le salon 775 ?
-- Il faut que le salon soit textuel et que l'utilisateur soit membre
-- du serveur qui contient ce salon.
SELECT EXISTS (
    SELECT 1
    FROM app.salon s
    JOIN app.membre m ON m.serveur_id = s.serveur_id
    WHERE s.id = 775
      AND s.type = 'texte'
      AND m.utilisateur_id = 1
) AS peut_ecrire;

-- R3 : nombre de messages et d'auteurs distincts par jour
-- sur le serveur 118 en octobre 2026.
SELECT
    date_trunc('day', m.envoye_le)::date AS jour,
    count(*) AS nb_messages,
    count(DISTINCT m.auteur_id) AS nb_auteurs
FROM app.message m
JOIN app.salon s ON s.id = m.salon_id
WHERE s.serveur_id = 118
  AND m.envoye_le >= timestamptz '2026-10-01 00:00:00+00'
  AND m.envoye_le <  timestamptz '2026-11-01 00:00:00+00'
GROUP BY date_trunc('day', m.envoye_le)::date
ORDER BY jour;
