# Architecture cible — version après mesures du TP2

Le prototype garde PostgreSQL comme source de vérité des données persistantes. Redis porte la présence avec une expiration native de cinq minutes. Les pièces jointes sont représentées par des métadonnées JSONB dans PostgreSQL ; les octets des fichiers sont destinés à un stockage objet en production. La vue matérialisée PostgreSQL fournit les statistiques quotidiennes et est rafraîchie par un traitement nocturne.

```mermaid
flowchart LR
    U[Utilisateur] --> API[Application / API]
    API -->|lecture et écriture transactionnelles| PG[(PostgreSQL
comptes, serveurs, membres, messages, amitiés)]
    API -->|renouvellement du TTL à chaque activité| R[(Redis
presence:utilisateur, TTL 5 min)]
    API -->|téléversement du fichier| OBJ[(Stockage objet
image / fichier)]
    API -->|métadonnées et référence| PG
    PG -->|rafraîchissement planifié, retard max visé : 1 jour| V[Vue matérialisée
activité par serveur et par jour]
    V -->|lecture du tableau de bord| API
    PG -->|lecture des droits et suggestions| API
```

## Choix après mesure

- PostgreSQL garde les comptes, les appartenances, les amitiés, les messages du prototype et les agrégats. Les mesures sur 300 000 messages ne justifient pas encore Cassandra/ScyllaDB.
- Redis est retenu comme second moteur si la contrainte impose deux moteurs : il accélère fortement l’écriture de présence et fournit le TTL. La lecture agrégée B2b ne gagne que légèrement ; elle peut rester dans PostgreSQL.
- Neo4j n’est pas retenu sur ce jeu de données : les requêtes de suggestions mesurées sont plus rapides dans PostgreSQL.
- Un stockage objet peut être ajouté quand la taille ou le trafic des pièces jointes le justifie.

La migration des messages vers ScyllaDB reste conditionnée à des mesures de volume, de concurrence et de latence p95 représentatives ; le benchmark Cassandra local ne permet pas de conclure sur ScyllaDB en cluster.
