# Mesures du TP2 — mon retour d’expérience

## Mission 0 — Observer les données avant de commencer

### Nombre de lignes dans les CSV

J’ai compté les lignes de chaque fichier CSV, sans compter la ligne d’en-tête :

|Fichier|Nombre de lignes|
|---|--:|
|utilisateurs.csv|5 000|
|serveurs.csv|150|
|salons.csv|974|
|membres.csv|7 984|
|messages.csv|300 000|
|amities.csv|15 000|

### Répartition des messages par salon

J’ai ensuite regardé comment les messages se répartissent entre les salons :

- Il y a 974 salons.
- Le minimum est de 0 message, la médiane de 41 et le maximum de 12 952.
- 375 salons ont moins de 20 messages.
- Les 10 salons les plus actifs contiennent 68 101 messages, soit 22,70 % du total.

### Salons que j’ai choisis pour les mesures

|Profil choisi|ID|Nom|Nombre de messages|
|---|--:|---|--:|
|Chaud|775|hors-sujet|12 952|
|Moyen|424|projets|90|
|Clairsemé|340|partage|2|

J’ai pris ces trois salons parce qu’ils ont des niveaux d’activité très différents. Ils me servent à comparer les moteurs, même s’ils ne reproduisent pas exactement les trois types de serveurs décrits dans le dossier documentaire.

En calculant le rythme depuis la création de chaque salon, j’obtiens environ 53 messages par jour pour le salon chaud, soit environ 19 500 par an. Il est actif, mais reste très loin d’un grand serveur public qui peut recevoir plusieurs millions de messages par an.

Le salon moyen reçoit environ 0,3 message par jour, soit près de 119 par an. Il ressemble davantage au profil d’un serveur surtout vocal, où les messages sont rares. Le salon clairsemé n’a reçu que deux messages en 247 jours.

### Ce que j’en conclus

Le jeu de données reproduit bien de gros écarts d’activité entre les salons, mais pas à l’échelle de Discord. Il contient 300 000 messages générés entre janvier et octobre 2026, alors que Discord a un historique et des volumes beaucoup plus importants.

Je peux donc comparer les moteurs sur ces données et sur cette machine, mais je ne peux pas en déduire leurs performances à l’échelle de Discord ni affirmer que ces choix conviendraient exactement à ses trois profils de serveurs.

## Mission 1 — Construire et charger le schéma PostgreSQL

Le fichier sql/01_schema.sql crée le schéma app avec les sept tables, leurs types, leurs clés, leurs contraintes et leurs index. Le fichier sql/02_chargement.sql copie les données de staging vers app.

J’ai comparé le nombre de lignes des tables app avec celui des tables staging. Les nombres correspondent :

|Table|Nombre de lignes|
|---|--:|
|utilisateur|5 000|
|serveur|150|
|salon|974|
|membre|7 984|
|message|300 000|
|amitie|15 000|
|presence|0|

La table presence est vide à ce moment-là. Elle est remplie ensuite pour les mesures de présence.

### Vérification des règles importantes

Mes requêtes de contrôle donnent les résultats suivants :

- Serveurs dont le propriétaire n’est pas membre avec le rôle proprietaire : **0**
- Serveurs qui n’ont pas exactement un membre avec le rôle proprietaire : **0**
- Messages envoyés dans un salon vocal : **0**

J’ai aussi essayé de violer six contraintes. PostgreSQL a refusé les six insertions :

1. **Adresse e-mail déjà utilisée**

   ~~~text
   ERROR: duplicate key value violates unique constraint "utilisateur_email_key"
   DETAIL: Key (email)=(user1@exemple.fr) already exists.
   ~~~

2. **Type de salon non autorisé**

   ~~~text
   ERROR: new row for relation "salon" violates check constraint "salon_type_check"
   DETAIL: Failing row contains (900000001, 1, preuve_type, audio, 2026-11-13 13:28:55.106989+00).
   ~~~

3. **Propriétaire inexistant**

   ~~~text
   ERROR: insert or update on table "serveur" violates foreign key constraint "serveur_proprietaire_id_fkey"
   DETAIL: Key (proprietaire_id)=(999999999) is not present in table "utilisateur".
   ~~~

4. **Pseudo obligatoire**

   ~~~text
   ERROR: null value in column "pseudo" of relation "utilisateur" violates not-null constraint
   DETAIL: Failing row contains (900000002, null, preuve_null@exemple.test, 2026-11-13 14:10:41.275014+00).
   ~~~

5. **Même utilisateur ajouté deux fois au même serveur**

   ~~~text
   ERROR: duplicate key value violates unique constraint "membre_pkey"
   DETAIL: Key (utilisateur_id, serveur_id)=(897, 1) already exists.
   ~~~

6. **Identifiants d’amitié dans le mauvais ordre**

   ~~~text
   ERROR: new row for relation "amitie" violates check constraint "amitie_check"
   DETAIL: Failing row contains (5000, 1, 2026-11-13 14:10:47.557988+00).
   ~~~

### Règles qui demandent aussi du code

Toutes les règles métier ne peuvent pas être garanties uniquement par une contrainte de base de données. Voici les choix que je retiens :

|Règle|Comment je la vérifie|Coût ou limite|
|---|---|---|
|Le propriétaire doit être membre de son serveur avec le rôle proprietaire|Je vérifie cette règle au chargement et avec une requête de contrôle périodique.|Pas de coût supplémentaire à chaque écriture, mais une anomalie pourrait rester jusqu’au prochain contrôle.|
|Un message doit être envoyé dans un salon textuel|L’application vérifie le type du salon avec R2 avant l’insertion.|Cette lecture est faite avant chaque message. Un trigger ferait aussi cette vérification à chaque insertion de message.|
|L’auteur doit être membre du serveur du salon|L’application vérifie l’appartenance avec R2 avant l’envoi.|Même coût que pour vérifier le type du salon ; R2 a pris 1,018 ms lors de son relevé unique.|

## Mission 2 — Mesurer les requêtes et les dénormalisations

### Mesure 2 — Temps des requêtes

J’ai activé \timing dans psql. Le tableau ci-dessous donne une exécution de chaque requête sur cette machine :

|Requête|Cas testé|Durée|
|---|---|--:|
|R1|Salon chaud, ID 775|3,160 ms|
|R1|Salon moyen, ID 424|1,032 ms|
|R1|Salon clairsemé, ID 340|0,561 ms|
|R2|Utilisateur 1, salon 775|1,018 ms|
|R3|Serveur 118, octobre 2026|25,914 ms|

R2 a renvoyé false : l’utilisateur 1 ne peut pas écrire dans le salon 775.

### Mesure 3 — Plan d’exécution de R3

Lors d’un premier relevé, R3 a pris **19,367 ms** avec EXPLAIN (ANALYZE, BUFFERS).

Le plan utilise un Bitmap Heap Scan pour aller chercher les messages. C’est un parcours qui s’appuie sur un index bitmap, et non un parcours séquentiel. Voici la ligne du nœud et les détails qui l’accompagnent :

~~~text
Bitmap Heap Scan on message m  (cost=15.74..1066.51 rows=45 width=24) (actual time=20.365..21.940 rows=482 loops=4)
  Recheck Cond: (salon_id = s.id)
  Filter: ((envoye_le >= '2026-10-01 00:00:00+00'::timestamp with time zone) AND (envoye_le < '2026-11-01 00:00:00+00'::timestamp with time zone))
  Rows Removed by Filter: 4377
  Heap Blocks: exact=5926
  Buffers: shared hit=2730 read=3333
  -> Bitmap Index Scan on idx_message_salon_id  (cost=0.00..15.73 rows=441 width=0) (actual time=5.308..5.308 rows=4859 loops=4)
       Index Cond: (salon_id = s.id)
       Buffers: shared hit=8 read=129
~~~

L’index idx_message_salon_id retrouve d’abord les messages par salon. Ensuite, PostgreSQL vérifie leur date. Comme envoye_le n’est pas dans cet index, la base doit lire des lignes avant de pouvoir écarter celles qui sont en dehors d’octobre.

Lors d’une autre exécution complète du plan, R3 a pris **90,695 ms** au total, avec une durée de planification de 9,136 ms. Ce n’est pas le même relevé que celui à 19,367 ms : le plan indique 3 336 blocs lus depuis le stockage. Les conditions de cache n’étaient donc pas les mêmes.

### Mesure 4 — R3 avec la vue matérialisée

La vue app.activite_serveur_jour contient **28 957 lignes**. Pour le serveur 118 et le mois d’octobre 2026, elle donne les mêmes résultats quotidiens que la requête R3.

|Opération|Durée|
|---|--:|
|Création de la vue matérialisée|488,337 ms|
|Création de l’index unique|20,932 ms|
|Lecture des 31 jours depuis la vue|1,100 ms|

La vue est plus rapide parce que les résultats sont déjà calculés. Elle ne se met toutefois pas à jour toute seule quand de nouveaux messages arrivent : il faut la rafraîchir.

### Test du compteur nb_membres

J’ai vérifié le trigger sur le serveur 1 en ajoutant puis en supprimant un membre :

|Étape|Valeur de nb_membres|
|---|--:|
|Avant l’insertion|12|
|Après l’insertion|13|
|Après la suppression|12|

Le trigger augmente le compteur quand un membre est ajouté et le diminue quand un membre est supprimé. Si un membre change de serveur, il met à jour les deux compteurs. Un changement de rôle ne modifie pas le nombre de membres.

### Ce que coûtent les deux dénormalisations

|Dénormalisation|Gain en lecture|Coût payé|Risque|Garde-fou|
|---|---|---|---|---|
|Vue matérialisée pour le tableau de bord|R3 passe de 25,914 ms à 1,100 ms dans les relevés uniques.|Il faut calculer la vue au départ, puis la rafraîchir régulièrement.|Les chiffres peuvent être en retard entre deux rafraîchissements.|Une tâche nocturne lance REFRESH MATERIALIZED VIEW CONCURRENTLY. L’index unique sur (serveur_id, jour) permet de continuer à lire la vue pendant le rafraîchissement.|
|Compteur serveur.nb_membres|On lit directement le nombre de membres sans recompter la table membre.|Le serveur est mis à jour à chaque ajout, suppression ou changement de serveur d’un membre.|Le compteur peut être faux si le trigger est désactivé ou contourné.|Le trigger est transactionnel, un CHECK empêche les valeurs négatives et une comparaison périodique avec count(*) permet de repérer un écart.|

J’ai choisi un rafraîchissement nocturne de la vue, parce qu’un jour de décalage est acceptable pour le tableau de bord. Un rafraîchissement normal bloque les lectures de la vue pendant son exécution. La version CONCURRENTLY les laisse continuer, mais elle utilise plus de ressources et demande un index unique.

Pour le compteur, le trigger incrémente ou décrémente la valeur au lieu de recompter tous les membres à chaque changement. Lors d’un changement de serveur, il touche l’ancien et le nouveau serveur. Lors d’un changement de rôle, le nombre ne bouge pas.

## Mission 3 — Comparer PostgreSQL, MongoDB et Cassandra pour les messages

### Modèles que j’ai chargés

**MongoDB.** J’ai créé une collection messages avec un document par message. Chaque document contient l’identifiant, le salon, le serveur, l’auteur, le contenu et la date d’envoi. Je n’ajoute pieces_jointes que lorsqu’un message en a une ; c’est le cas d’environ 8 % des messages d’après generate_data.py.

J’ai copié serveur_id dans le document pour que la requête B4 n’ait pas besoin de joindre la table salon. Cette copie serait à mettre à jour si le salon changeait de serveur. Je n’ai pas copié modifie_le, car B1 et B4 n’en ont pas besoin.

J’ai créé deux index : salon_id et _id décroissant pour retrouver les derniers messages d’un salon (B1), puis serveur_id et envoye_le pour calculer l’activité d’un serveur sur une période (B4).

**Cassandra.** J’ai créé la table messages_par_salon avec une partition par salon et fenêtre de 10 jours : (salon_id, bucket). L’identifiant du message sert de clé de tri, en ordre décroissant. C’est l’option B de mon dossier de conception. Les pièces jointes sont enregistrées comme texte JSON. Quand modifie_le ou pieces_jointes n’a pas de valeur, je n’envoie pas de NULL : j’utilise UNSET_VALUE pour éviter de créer des tombstones.

### Mesure 5a — Vérifier le nombre de messages migrés

|Moteur|Nombre de messages|
|---|--:|
|PostgreSQL|300 000|
|MongoDB|300 000|
|Cassandra, total de 15 965 partitions|300 000|

Je n’ai pas utilisé SELECT count(*) sans clé de partition dans Cassandra, car cette requête devrait parcourir toute la table. Cela devient de plus en plus coûteux et peut gêner les autres lectures. À la place, j’ai compté chaque partition séparément et comparé les résultats avec PostgreSQL, regroupés par salon et fenêtre. Sur les 15 965 partitions, je n’ai trouvé **aucun écart**.

### Mesure 5b — Comparer les identifiants renvoyés

J’ai vérifié que les trois moteurs renvoient les mêmes identifiants dans le même ordre :

|Salon|Messages lus|Premier identifiant|Dernier identifiant|Même résultat dans les trois moteurs ?|
|---|--:|---:|---:|---|
|Chaud 775|50|1566236554475901907|1565815739628425005|Oui|
|Moyen 424|50|1565571041806552170|1505342927315012592|Oui|
|Clairsemé 340|2|1506449269769508853|1495704893778929071|Oui|

Le salon clairsemé ne contient que deux messages, donc les moteurs en renvoient deux au lieu de 50.

### Mesure 6 — Temps de lecture B1

J’ai mesuré 300 lectures pour chaque cas, après 10 lectures d’échauffement. Le tableau indique la médiane (p50) et le 95e centile (p95), en millisecondes :

|Salon et nombre de messages|PostgreSQL p50 / p95|MongoDB p50 / p95|Cassandra p50 / p95|
|---|---:|---:|---:|
|Chaud 775 (12 952)|0,18 / 0,32|0,40 / 0,45|1,08 / 1,51|
|Moyen 424 (90)|0,18 / 0,27|0,39 / 0,43|12,96 / 18,81|
|Clairsemé 340 (2)|0,16 / 0,27|0,49 / 0,53|16,77 / 24,40|

Par rapport à PostgreSQL au p50, MongoDB est 2,2 fois plus lent pour le salon chaud et le salon moyen, et 3,1 fois plus lent pour le salon clairsemé. Cassandra est 6 fois plus lente sur le salon chaud, 72 fois sur le moyen et 105 fois sur le clairsemé.

#### L’écart entre le salon chaud et le salon clairsemé

L’écart n’est pas le même pour les trois moteurs. Entre le salon chaud et le salon clairsemé, PostgreSQL reste presque stable (0,18 à 0,16 ms). MongoDB augmente un peu (0,40 à 0,49 ms, soit ×1,2). Cassandra passe de 1,08 à 16,77 ms, soit ×15,5.

#### Pourquoi Cassandra lit-elle plus de partitions ?

Pour obtenir les 50 messages, le code commence par la fenêtre de 10 jours la plus récente de la plateforme. Il remonte ensuite les fenêtres du salon jusqu’à trouver 50 messages ou arriver à la date de création du salon. J’ai estimé le nombre de partitions lues en rejouant ce fonctionnement sur les CSV :

|Salon|Messages|Messages par jour|Partitions lues par Cassandra|p50 Cassandra|p50 estimé par partition|
|---|--:|--:|--:|--:|--:|
|Chaud 775|12 952|≈ 53|1|1,08 ms|1,08 ms|
|Moyen 424|90|≈ 0,3|18|12,96 ms|0,72 ms|
|Clairsemé 340|2|≈ 0,01|26|16,77 ms|0,65 ms|

Une partition en plus ajoute environ 0,6 ms dans ces mesures. La latence de Cassandra dépend donc surtout du nombre de partitions parcourues, pas du nombre total de messages du salon. Le salon clairsemé ne peut jamais fournir 50 messages : Cassandra parcourt ses 26 fenêtres, dont 24 sont vides.

Dans mon calcul de conception, j’avais estimé qu’un salon avec 1 000 messages par an demanderait environ deux partitions avec des fenêtres de 10 jours. Le salon moyen reçoit environ 119 messages par an, soit autour de 3,3 messages par fenêtre. Pour arriver à 50, le calcul donne environ 15 fenêtres ; la mesure en compte 18, car les messages ne sont pas répartis régulièrement. J’observe donc bien le compromis prévu : les petites fenêtres limitent la taille des partitions des salons actifs, mais elles obligent à parcourir beaucoup de fenêtres pour les salons peu actifs.

**Correctif optionnel non réalisé.** L’énoncé propose de garder la liste des fenêtres qui contiennent des messages. Pour le salon clairsemé, cela pourrait réduire le nombre de lectures de 26 à 2. Le gain serait moins important pour le salon moyen, parce que 26 de ses 29 fenêtres ne sont pas vides et que la lecture s’arrête quand elle a trouvé assez de messages.

### Ce que ces mesures disent sur MongoDB et Cassandra

À ce petit volume, MongoDB ne montre pas les problèmes décrits dans l’article : ses temps restent entre 0,39 et 0,49 ms au p50, avec un p95 au plus à 0,53 ms. Dans le scénario de 2015, 100 millions de messages à 300 octets chacun représentent environ 30 Go. L’index composé à 40 octets par entrée représente environ 4 Go. Avec 16 Go de mémoire, l’index peut tenir en mémoire alors que toutes les données n’y tiennent plus. Ici, les 300 000 messages occupent environ 90 Mo, donc ils tiennent en mémoire.

Cassandra n’est pas plus rapide que PostgreSQL ou MongoDB pour ces trois salons. Elle devient même beaucoup plus lente quand le salon est peu actif, parce qu’elle doit parcourir davantage de fenêtres.

Pour que la comparaison change, il faudrait tester un volume qui dépasse la mémoire disponible, par exemple autour de 50 millions de messages d’après les hypothèses du dossier, ou ajouter une vraie charge concurrente. Ces situations ne sont pas reproduites par les 300 000 messages du TP.

## Mission 4 — Reproduire et corriger l’incident des tombstones

### Mesure 9 — Reproduction

Après avoir attendu que Cassandra accepte les connexions, j’ai lancé le scénario sur une partition de test (salon -1, bucket 0). Au premier essai, la lecture a renvoyé 50 messages en 10 ms. Après 119 999 suppressions ligne par ligne, elle a échoué en 255 ms alors qu’il restait le message le plus ancien. J’ai refait le test : 50 messages en 4 ms au départ, puis le même échec en 144 ms.

La sortie du script est tronquée à 160 caractères :

~~~text
après 119999 suppressions ligne par ligne (il reste 1 message, le plus ancien) : ÉCHEC après 255 ms : Error from server: code=1300 [Replica(s) failed to execute read] message="Operation failed - received 0 responses and 1 failures: READ_TOO_MANY_TOMBSTONES from
~~~

Le journal Cassandra donne le détail complet. Le script envoie une lecture de message_id pour la partition demandée. Le journal affiche SELECT * avec ALLOW FILTERING, car Cassandra reconstruit sa propre représentation de la requête pour le diagnostic. Cette représentation peut différer de la requête envoyée et afficher ALLOW FILTERING même quand il n’est pas nécessaire ([code Cassandra 4.1](https://github.com/apache/cassandra/blob/cassandra-4.1/src/java/org/apache/cassandra/db/AbstractReadQuery.java#L86-L109)). Dans les deux cas, le journal confirme 100 001 tombstones pour la partition de test et l’abandon de la lecture.

~~~text
WARN  [ReadStage-2] Read 0 live rows and 100001 tombstone cells for query SELECT * FROM discord.messages_par_salon WHERE salon_id = -1 AND bucket = 0 LIMIT 50 ALLOW FILTERING (see tombstone_warn_threshold)
ERROR [ReadStage-2] Scanned over 100001 tombstones during query 'SELECT * FROM discord.messages_par_salon WHERE salon_id = -1 AND bucket = 0 LIMIT 50 ALLOW FILTERING' (last scanned row token was -3044509270762677278 and partition key was ((-1, 0), 20000)); query aborted
~~~

### Ce que j’ai compris de l’incident

1. Chaque suppression ligne par ligne laisse un marqueur appelé tombstone.
2. Cassandra doit parcourir ces marqueurs pour savoir quelles lignes supprimées ne doivent plus apparaître.
3. Le script garde l’identifiant 1 et supprime les identifiants 2 à 120 000. Comme la clé de tri est décroissante, le message restant est le plus ancien et se trouve derrière les tombstones.
4. Quand il y a trop de marqueurs, la lecture demande beaucoup de travail et peut provoquer des ralentissements ou des pauses.
5. Cassandra finit par refuser la lecture au-delà du seuil prévu, pour éviter qu’elle monopolise les ressources du serveur. Augmenter le seuil ne ferait que masquer le problème.

### Les deux corrections testées

|Correction|Résultat|
|---|---|
|Purge pédagogique : gc_grace_seconds réglé temporairement à 0, flush, compaction, puis valeur restaurée à 864000|La lecture de contrôle retrouve le seul message encore vivant : message_id = 1 (1 ligne).|
|python tombstones.py --reparer|Avant de supprimer toute la partition : 50 messages lus en 4 ms. Après la suppression de la partition entière : 0 message en 8 ms.|

La purge ne doit être faite que dans le TP mono-nœud. En production, mettre gc_grace_seconds à zéro peut faire réapparaître des données supprimées si une réplique n’a pas reçu le marqueur à temps. Il faut tenir compte de la réplication et des réparations avant de supprimer des tombstones.

Avec --reparer, le script supprime la partition d’un coup au lieu de créer 119 999 suppressions ligne par ligne. Cette méthode suppose qu’on peut supprimer ou reconstruire toute la partition ; elle ne répare pas automatiquement une partition historique quelconque. La suppression de toute une partition laisse elle aussi un marqueur de plage, qui suit ensuite le cycle normal de Cassandra.

## Mission 5 — Tester Redis et Neo4j

### Vérifier que les moteurs répondent pareil

Avant de chronométrer, le programme vérifie avec des assert que les réponses concordent pour B1, B2b, B3, B3 bis et B4. Pour les suggestions, j’ai testé 20 utilisateurs tirés au hasard. Tous les contrôles ont réussi.

Sans ces contrôles, je pourrais comparer des résultats différents : un moteur qui renvoie moins de lignes pourrait avoir l’air plus rapide simplement parce qu’il fait moins de travail.

### Mesure 7 — Temps mesurés

Voici les médianes (p50) et les 95e centiles (p95), en millisecondes :

|Cas testé|PostgreSQL p50 / p95|Redis ou Neo4j p50 / p95|Comparaison des p50|
|---|---:|---:|---|
|B2a, écriture de présence|2,10 / 3,81|Redis : 0,16 / 0,34|Redis est 13 fois plus rapide|
|B2b, membres en ligne dans un serveur de 478 membres|4,11 / 4,29|Redis : 3,72 / 4,11|Redis est 1,1 fois plus rapide|
|B3, suggestions de serveurs|0,29 / 0,46|Neo4j : 5,41 / 7,78|PostgreSQL est 19 fois plus rapide|
|B3 bis, amis d’amis (30 essais)|0,37 / 0,64|Neo4j : 5,76 / 7,32|PostgreSQL est 16 fois plus rapide|

Pour B3 bis, je n’ai fait que 30 essais ; le p95 est donc moins représentatif.

### Vérifier l’expiration automatique de Redis

J’ai créé une clé Redis valable 10 secondes. Les sorties confirment qu’elle disparaît sans commande de suppression :

~~~text
SET presence:test en_ligne EX 10  → OK
TTL presence:test                 → (integer) 10
(après sleep 11)
GET presence:test                 → (nil)
~~~

Pour obtenir un comportement proche dans PostgreSQL, je dois filtrer les lectures sur les présences des cinq dernières minutes. La ligne reste toutefois dans la table ; il faut donc aussi prévoir un nettoyage périodique, par exemple un DELETE des lignes dont vu_le date de plus de cinq minutes. Les mises à jour fréquentes créent également des versions mortes que l’autovacuum doit nettoyer.

### Ce que j’en conclus

Redis gagne clairement sur l’écriture du battement de cœur : une clé en mémoire avec TTL est plus rapide que l’écriture PostgreSQL, qui met aussi à jour son journal et son index.

Pour B2b, Redis gagne seulement un peu. Il faut lire la liste des 478 membres, puis chercher leurs clés de présence avec MGET. PostgreSQL fait la jointure en une seule requête ; dans ce test, cela revient presque au même.

Neo4j est plus lent que PostgreSQL pour B3 et B3 bis. Le graphe est petit : il y a 5 000 utilisateurs et 15 000 amitiés, soit environ six amis par personne. PostgreSQL retrouve les résultats grâce à ses index sans que Neo4j ait assez de grands parcours relationnels à faire pour compenser ses coûts de connexion et d’exécution.

## Mission 6 — Comparer mes hypothèses aux résultats

### Mesure 8 — Résultats du benchmark

Les mesures de benchmark ci-dessous sont celles déjà relevées dans le dossier. La machine indiquée pendant la préparation du compte rendu était un AMD Ryzen 5 7535HS avec Radeon Graphics, avec 14 GiB de mémoire visible, Linux 7.0.0-43-generic, Docker 29.9.3 et Docker Compose 5.7.1. La mémoire visible peut différer de la limite configurée pour Docker Desktop.

|Cas|Moteur|p50 (ms)|p95 (ms)|
|---|---|--:|--:|
|B1, derniers messages, salon chaud|PostgreSQL|0,18|0,32|
|B1, derniers messages, salon chaud|MongoDB|0,40|0,45|
|B1, derniers messages, salon chaud|Cassandra|1,08|1,51|
|B1, salon chaud, correctif Cassandra optionnel|Non réalisé|—|—|
|B1, derniers messages, salon moyen|PostgreSQL|0,18|0,27|
|B1, derniers messages, salon moyen|MongoDB|0,39|0,43|
|B1, derniers messages, salon moyen|Cassandra|12,96|18,81|
|B1, salon moyen, correctif Cassandra optionnel|Non réalisé|—|—|
|B1, derniers messages, salon clairsemé|PostgreSQL|0,16|0,27|
|B1, derniers messages, salon clairsemé|MongoDB|0,49|0,53|
|B1, derniers messages, salon clairsemé|Cassandra|16,77|24,40|
|B1, salon clairsemé, correctif Cassandra optionnel|Non réalisé|—|—|
|B2a, écriture de présence|PostgreSQL|2,10|3,81|
|B2a, écriture de présence|Redis|0,16|0,34|
|B2b, présence dans un serveur de 478 membres|PostgreSQL|4,11|4,29|
|B2b, présence dans un serveur de 478 membres|Redis|3,72|4,11|
|B3, suggestions de serveurs|PostgreSQL|0,29|0,46|
|B3, suggestions de serveurs|Neo4j|5,41|7,78|
|B3 bis, amis d’amis (30 essais)|PostgreSQL|0,37|0,64|
|B3 bis, amis d’amis (30 essais)|Neo4j|5,76|7,32|
|B4, activité d’un serveur sur 31 jours|PostgreSQL normalisé|16,37|16,90|
|B4, activité d’un serveur sur 31 jours|PostgreSQL avec vue matérialisée|0,23|0,30|
|B4, activité d’un serveur sur 31 jours|MongoDB, agrégation|5,89|7,00|

Pour le serveur 118, qui a environ 1 900 messages en octobre, la vue matérialisée est 71 fois plus rapide que la requête PostgreSQL normalisée (16,37 à 0,23 ms). Elle est aussi environ 26 fois plus rapide que l’agrégation MongoDB. MongoDB évite la jointure grâce à serveur_id copié dans chaque document, mais il recalcule l’agrégation à chaque lecture.

Les mesures uniques de la Mission 2 donnaient 25,914 ms pour R3 et 1,100 ms pour la vue. Le benchmark répète chaque accès 300 fois après échauffement et donne des médianes de 16,37 et 0,23 ms. Les premières exécutions peuvent avoir des coûts de planification et de cache différents ; pour comparer les moteurs, je m’appuie surtout sur les résultats répétés du benchmark.

### Résultat de mes cinq hypothèses

Le dossier parlait de ScyllaDB, alors que le TP fournit Cassandra. Je présente donc les résultats comme des comparaisons avec Cassandra, sans supposer que les chiffres seraient identiques avec ScyllaDB.

|#|Hypothèse de départ|Résultat mesuré|Verdict|Ce que j’en comprends|
|---|---|---|---|---|
|1|PostgreSQL et ScyllaDB seraient à moins de ×1,5 pour B1 sur 300 000 messages.|Cassandra est ×6 plus lente sur le salon chaud, ×72 sur le moyen et ×105 sur le clairsemé.|Infirmée pour Cassandra ; ScyllaDB n’a pas été testée.|Cassandra lit plusieurs fenêtres de 10 jours pour les salons peu actifs. PostgreSQL utilise un seul index salon/id.|
|2|ScyllaDB serait environ deux fois plus rapide que PostgreSQL pour B1 sur un grand salon.|PostgreSQL est ×6 plus rapide que Cassandra sur le salon chaud : 0,18 contre 1,08 ms.|Infirmée pour Cassandra.|À ce volume, PostgreSQL tient en mémoire sur un seul nœud. Cassandra paie le coût du coordinateur et du pilote sans profiter d’un cluster.|
|3|PostgreSQL serait environ deux fois plus rapide que MongoDB pour B1.|PostgreSQL est ×2,2 plus rapide pour les salons chaud et moyen, et ×3,1 pour le clairsemé.|Confirmée sur ces essais.|Les deux moteurs utilisent un index composé. Le benchmark ne mesure que les identifiants, donc il n’isole pas l’effet de chaque index.|
|4|Redis serait environ cinq fois plus rapide pour lire une présence individuelle.|La lecture individuelle n’a pas été mesurée. B2b est seulement ×1,1 plus rapide avec Redis ; l’écriture B2a est ×13 plus rapide.|Indécidable pour la lecture individuelle ; l’hypothèse ne se confirme pas pour B2b.|La présence dans un serveur demande 478 recherches Redis, alors que PostgreSQL fait une jointure en une requête.|
|5|PostgreSQL serait environ deux fois plus rapide que ScyllaDB pour lire un agrégat déjà calculé.|Je n’ai pas testé Cassandra ou ScyllaDB pour cet accès. La vue PostgreSQL lit en 0,23 ms au p50.|Indécidable.|J’ai gardé le tableau de bord dans PostgreSQL, où les messages sont déjà stockés dans le prototype.|

### Limites des essais

1. **Le volume est faible.** 300 000 messages représentent environ 90 Mo et tiennent en mémoire. Les problèmes observés par Discord quand les données dépassaient la mémoire ne sont donc pas reproduits.
2. **Il n’y a presque pas de concurrence.** Un seul client répète la même entrée 300 fois après échauffement. Cela ne reproduit pas les lectures très aléatoires, les partitions chaudes ou les serveurs vocaux dont les données sont rarement consultées.
3. **Tout tourne localement.** Cassandra est un seul nœud, sans réplication ni quorum. Les latences seraient différentes avec plusieurs machines et un vrai réseau.

Le p95 m’intéresse parce qu’il montre les requêtes les plus lentes, que la moyenne peut cacher. Si une requête sur vingt est lente, certains utilisateurs le ressentent même si le temps moyen reste bon. L’échauffement sert à ne pas mélanger les coûts de démarrage (connexions, plans de requête et cache) avec les temps habituels.

### Comment j’ai révisé mes choix d’architecture

- **Comptes et relations : choix maintenu.** PostgreSQL reste mon choix. Les requêtes de suggestions PostgreSQL prennent entre 0,29 et 0,64 ms au p50/p95, tandis que Neo4j est 16 à 19 fois plus lent sur ce petit graphe.
- **Messages : choix modifié.** Au départ, j’envisageais ScyllaDB si la charge le justifiait. Pour le prototype, PostgreSQL suffit : son p95 pour B1 est entre 0,27 et 0,32 ms. Les mesures ne permettent pas de décider pour un très gros volume ou une forte concurrence.
- **Tableau de bord : choix maintenu, mais réalisé dans PostgreSQL.** La vue matérialisée passe de 16,37 à 0,23 ms au p50. Je ne l’ai pas déplacée dans ScyllaDB.
- **Version à deux moteurs : choix modifié.** Je garde PostgreSQL pour les données persistantes et Redis pour la présence. Redis est 13 fois plus rapide pour l’écriture et expire les clés automatiquement. Si les seuils sont tenus, PostgreSQL seul peut aussi suffire à ce petit volume.

Je surveillerais la latence p95 des messages et le volume de données avant d’ajouter Cassandra ou ScyllaDB. Je garderais Neo4j en option seulement si les suggestions dépassent régulièrement 200 ms malgré les index et les optimisations relationnelles. Pour la présence, Redis devient utile si l’expiration autonome est nécessaire ou si les écritures chargent trop PostgreSQL. Le TP ne teste pas la concurrence, le réseau distribué ni les volumes de production : ces seuils sont des raisons de refaire des mesures, pas des conclusions sur Discord.

Si je ne pouvais garder que deux moteurs, je choisirais donc PostgreSQL et Redis pour ce prototype. Ma réponse a changé depuis le jour 1 : les mesures ne justifient pas ScyllaDB ici, tandis que Redis apporte un gain clair sur l’écriture de présence et le TTL natif.
