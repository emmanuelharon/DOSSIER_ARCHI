CREATE KEYSPACE IF NOT EXISTS discord
WITH replication = {'class': 'SimpleStrategy', 'replication_factor': 1};

USE discord;

-- Une partition représente un salon pendant une fenêtre de 10 jours.
-- Les Snowflakes étant ordonnés dans le temps, l'ordre décroissant renvoie
-- directement les messages les plus récents d'une fenêtre.
CREATE TABLE IF NOT EXISTS messages_par_salon (
    salon_id bigint,
    bucket bigint,
    message_id bigint,
    auteur_id bigint,
    contenu text,
    envoye_le timestamp,
    modifie_le timestamp,
    pieces_jointes text,
    PRIMARY KEY ((salon_id, bucket), message_id)
) WITH CLUSTERING ORDER BY (message_id DESC);
